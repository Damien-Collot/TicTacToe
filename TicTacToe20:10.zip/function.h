#include <stdbool.h>
void firstAffiche(int tableau[3][3]);
void afficheMatrice(int tableau[3][3]);
bool win(int tab[3][3], int joueur);
bool CheckCoup(int tab[3][3],int valCoup);
bool CheckCoupComputer(int tab[3][3],int valCoup);
